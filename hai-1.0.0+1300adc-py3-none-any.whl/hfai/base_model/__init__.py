

try:
    from utils import setup_custom_finder
    setup_custom_finder()
except Exception:
    pass
