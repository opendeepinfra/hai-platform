
class UserExtras:
    pass
